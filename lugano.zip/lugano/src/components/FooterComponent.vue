<template>
  <div class="dash-footer">
    <div class="container text-center">
      <p>&copy; 2022</p>
    </div>
  </div>
</template>

<script>
export default {
  name: "FooterComponent",
};
</script>
