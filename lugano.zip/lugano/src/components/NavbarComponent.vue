<template>
  <!---------------------- template left navbar ---------------------->
  <nav id="nav-left-sidebar" class="nav-left-sidebar d-flex flex-column">
    <button id="nav-left-btn" class="nav-btn btn" type="button">
      <span><i class="icofont-navigation-menu"></i></span>
    </button>
    <div class="nav-left-header">
      <div class="dash-brand text-center">
        <a href="/">
          <!-- <img src="/images/logo.png" /> -->
        </a>
      </div>
      <div class="dropdown mt-3">
        <a
          href="#"
          class="dropdown-ellipses dropdown-toggle mr-2"
          role="button"
          data-toggle="dropdown"
          aria-haspopup="true"
          aria-expanded="false"
        >
          <div class="avatar d-flex align-items-center">
            <img src="/images/logo.png" class="avatar-img rounded-circle" />
            <h5 class="ml-2 text-light text-uppercase">e-RISITI</h5>
          </div>
        </a>
        <div class="dropdown-menu dropdown-menu-right">
          <a href="#" class="dropdown-item"> <i class="icofont-ui-lock mr-1"></i> Change Password </a>
          <a href="#" class="dropdown-item"> <i class="icofont-ui-power mr-1"></i> Log Out </a>
        </div>
      </div>
    </div>
    <hr class="mb-2" />
    <ul class="nav flex-column h-100 nice-scroll">
      <li class="nav-item">
        <a class="nav-link" href="/dashboard"> <i class="icofont-dashboard"></i> Dashboard </a>
      </li>

       <li class="nav-item">
        <a class="nav-link" href="/dashboard/profile"> <i class="icofont-user-alt-7"></i> Receipt</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" href="/dashboard/profile"> <i class="icofont-list"></i> Report </a>
     </li>
      <li class="nav-item dropdown-ellipses  mr-2 dropdown mt-3">
        <a class="nav-link " role="button"
          data-toggle="dropdown" aria-haspopup="true"  aria-expanded="false"> <i class="icofont-list"></i> TAXS 
         </a>
        <div class="dropdown-menu dropdown-menu-right">
          <a href="/dashboard/profile" class="dropdown-item"> <i class="icofont-list"></i> TOZO </a>
          <a href="#" class="dropdown-item"> <i class="icofont-list"></i>VAT </a>
        </div>


        
       
     </li>



      
      
    </ul>

    <div class="sidebar-footer mt-2">
      <hr />
      <p class="text-center">Version 1.0.0</p>
    </div>
  </nav>
</template>

<script>
export default {
  name: "NavbarComponent",
};
</script>
<style scoped>

</style>
