<template>
  <div class="dashboard-main-wrapper">
    <!---------------------- template left navbar ---------------------->
    <NavbarComponent />
    <div class="dashboard-wrapper nice-scroll">
      <!---------------------- template dashboard-content ---------------------->
      <div class="dashboard-content container-fluid d-flex flex-column">
        <!---------------------- template pages ---------------------->
        <div class="page">
          <div class="page-header">
            <div class="d-flex justify-content-between align-items-center">
              <h4 class="page-header-title">{{ title }}</h4>
            </div>
          </div>
          <router-view />
        </div>
        <!---------------------- footer ---------------------->
        <FooterComponent />
      </div>
    </div>
  </div>
</template>

<script>
import NavbarComponent from "../components/NavbarComponent.vue";
import FooterComponent from "../components/FooterComponent.vue";

export default {
  name: "DashboardView",

  components: {
    NavbarComponent,
    FooterComponent,
  },

  data() {
    return {
      title: "DASHBOARD",
    };
  },

  mounted() {
    this.title = this.$route.meta.title;
  },
};
</script>
<style>
.dash-brand {
  display: block;
  text-align: center;
}
.dash-brand img {
  width: auto;
  height: 32px;
}
</style>
