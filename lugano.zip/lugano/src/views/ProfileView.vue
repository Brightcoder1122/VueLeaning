<template>
<div>




<div class="main_container">
    <!-- Page Heading -->
    <div class="row animated--grow-in">
        <div class="col-xl-12">
            <div class="card card-body">
                <div class="d-sm-flex align-items-center justify-content-end mb-4">
                    <button class="d-none d-sm-inline-block btn btn-info btn-sm shadow-sm" data-toggle="modal" data-target="#newRoute">TOZO RIDIRECT<i class="fa fa-plus fa-sm"></i> 
                    </button>
                    <button class="d-none d-sm-inline-block btn btn-secondary btn-sm shadow-sm ml-2" data-toggle="modal" data-target="#newStation">ADD TOZO <i class="fa fa-plus fa-sm"></i> 
                    </button>
                </div>
               
                <div class="table-responsive">
                    <!-- <table class="table table-sm table-striped table-hover dt-responsive display nowrap" id="dataTable" width="100%" cellspacing="0"> -->
                      <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Redirect</th>
                                <th>Amount</th>
                                <th>Site</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                          
                            <tr class="text-dark">                               
                            <td>John</td>
                            <td>Doe</td>
                            <td>john@example.com</td>
                            <td>John</td>
                           
                                 <input type="checkbox" checked data-toggle="toggle" data-onstyle="success">
                              
                            </tr>
                             <tr>
                        <td>Mary</td>
                        <td>Moe</td>
                        <td>mary@example.com</td>
                        <td>John</td>
                        <input type="checkbox" checked data-toggle="toggle" data-onstyle="success">
                        </tr>

 
                        
                         
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>






<div class="modal fade" id="newRoute" tabindex="-1" role="dialog" aria-labelledby="newRoute" aria-hiden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="user">TOZO RIDIRECT</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="text-white">&times;</span>
                </button>
            </div>
            <form action="route-logic.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-xl-12 mt-2">
                            <label>RIDIRECT NAME</label>
                            <input type="text" name="origin" class="form-control" placeholder="Name" required>
                        </div>
                        
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="submit" name="save_route" class="btn btn-info">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="modal fade" id="newStation" tabindex="-1" role="dialog" aria-labelledby="newStation" aria-hiden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="user">Add TOZO</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="text-white">&times;</span>
                </button>
            </div>
            <form action="station-logic.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-xl-12 mt-2">
                            <label>AMOUNT</label>
                                                   <input type="number" name="price" class="form-control" placeholder="Price" required>

                        </div>
                        <div class="col-xl-12 mt-2">
                            <label>REDIRECT</label>
                            <select name="route" class="form-control">
                              
                                    <option value=''>select</option> 
                                    <option value="USAFIRISHAJI">
                                        
                                    </option>
                                
                            </select>
                        </div>
                         <div class="col-xl-12 mt-2">
                            <label>SITE</label>
                            <select name="route" class="form-control">
                              
                                    <option value=''>Tanzania</option> 
                                    <option value=''>Zanzibari</option> 
                                        
                                    
                                
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" name="save_station" class="btn btn-info">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

</div> 
</template>

<script>
export default {
  name: "ProfileView",
};

</script>

<style scoped>

</style>
