import Vue from "vue";
import VueRouter from "vue-router";
import ProfileView from "../views/ProfileView";
import StatView from "../views/StatView";
import DashboardView from "../views/DashboardView";
// import LoginView from '@/views/LoginView';
import LandingPageView from '@/views/LandingPageView';


Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "home",
    component: LandingPageView,
  },
  //         {
  //   path: '/login',
  //   name: 'LoginView',
  //   component: LoginView
  // },
  {
    path: "/dashboard",
    name: "dashboard",
    component: DashboardView,
    meta: {
      title: "DASHBOARD",
    },
    children: [
      {
        path: "",
        name: "statistics",
        component: StatView,
        meta: {
          title: "STATISTICS",
        },
      },
  
      {
        path: "profile",
        name: "profile",
        component: ProfileView,
        meta: {
          title: "PROFILE",
        },
      },

    ],
  },


];

const router = new VueRouter({
  mode: "history",
  routes,
});

export default router;
