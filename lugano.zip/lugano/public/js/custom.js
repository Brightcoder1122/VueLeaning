/* eslint-disable no-undef */
$(document).ready(function () {
  var base_url = baseUrl();

  /*-----------------------
     side bar button
    -------------------------*/
  $("#nav-left-btn").on("click", function () {
    $("#nav-left-sidebar").toggleClass("active");
    $(".dashboard-wrapper").toggleClass("pull-right");
  });

  /*-----------------------
     info status hide
    -------------------------*/
  $(".info-hide").on("click", function () {
    $(this).fadeOut(1000, function () {
      $(this).remove();
    });
  });

  /*-----------------------
     check box
    -------------------------*/
  $("#row-check-all").on("click", function () {
    // select multiple check box
    if ($(this).is(":checked")) {
      $(".row-check-item").prop("checked", true);
      $(".row-check-item").closest("tr").addClass("table-active");
    } else {
      $(".row-check-item").prop("checked", false);
      $(".row-check-item").closest("tr").removeClass("table-active");
    }
  });

  $(".row-check-item").on("click", function () {
    // select single check box

    if ($(this).is(":checked")) {
      $(this).closest("tr").addClass("table-active");
    } else {
      $(this).closest("tr").removeClass("table-active");
    }
  });

  /*-----------------------
     functions
    -------------------------*/

  function baseUrl() {
    // get base url
    var pathparts = location.pathname.split("/");
    var host_array = ["localhost", "127.0.0.1"];
    var current_host = location.host;

    if (host_array.includes(current_host)) {
      var url = location.origin + "/" + pathparts[1].trim("/") + "/";
    } else {
      url = location.origin;
    }
    return url;
  }
});

'use strict';

/**
 * navbar variables
 */

const navToggleBtn = document.querySelector("[data-nav-toggle-btn]");
const header = document.querySelector("[data-header]");

navToggleBtn.addEventListener("click", function () {
  header.classList.toggle("active");
});

// graph

