<template>
 <div>
  
  <header class="header" data-header>
    <div class="container">

      <a href="#" class="logo">
        <h3 style="text-size: 10">LOGO</h3>
      </a>

      <button class="menu-toggle-btn" data-nav-toggle-btn data-toggle="collapse" data-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <ion-icon name="menu-outline"></ion-icon>
      </button>

      <nav class="navbar" >
        <ul class="navbar-list">


        </ul>

        <div class="header-actions "  >

          <a href="#hero" class="navbar-link">Home</a> 
          <a href="#features" class="navbar-link">About</a>
          <a href="#" class="header-action-link" data-toggle="modal" data-target="#myModal">Log in</a>

          <a href="#" class="header-action-link">Register</a>
        </div>
      </nav>

    </div>
  </header>





  <main>
    <article>

      <!-- 
        - HERO
      -->

      <section class="hero" id="hero">
        <div class="container">

          <div class="hero-content">
            <h2 class="h2 hero-title" style="font-weight: bold; font-size: 35px;">e-RISITI SYSTEM </h2>
            

            <p class="hero-text " style="font-weight: bold; font-size: 17px;">
             A software engine that generate a digital receipt
            </p>

          

          </div>

          <figure class="hero-banner">
            <img src="images/hero-banner.png" alt="Hero image">
          </figure>

        </div>
      </section>





      <!-- 
        - ABOUT
      -->

      <section class="about">
        <div class="container">

          <!-- <div class="about-content">

            <div class="about-icon">
              <ion-icon name="cube"></ion-icon>
            </div>

            <h2 class="h2 about-title">Why Choose Us ?</h2>

            <p class="about-text">
              Nam libero tempore cum soluta as nobis est eligendi optio cumque nihile impedite quo minus id quod maxime.
            </p>

            <button class="btn btn-outline">Learn More</button>

          </div> -->

          <ul class="about-list">

            <li>
              <div class="about-card">

                <div class="card-icon">
                  <ion-icon name="thumbs-up"></ion-icon>
                </div>

                <h3 class="h3 card-title">e-RISITI WEB</h3>

                <p class="card-text">
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem.
                </p>

              </div>
            </li>

            <li>
              <div class="about-card">

                <div class="card-icon">
                  <ion-icon name="trending-up"></ion-icon>
                </div>

                <h3 class="h3 card-title">e-RISITI App</h3>

                <p class="card-text">
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem.
                </p>

              </div>
            </li>

            <li>
              <div class="about-card">

                <div class="card-icon">
                  <ion-icon name="shield-checkmark"></ion-icon>
                </div>

                <h3 class="h3 card-title">e-RISITI USSD</h3>

                <p class="card-text">
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem.
                </p>

              </div>
            </li>

            <li>
              <div class="about-card">

                <div class="card-icon">
                  <ion-icon name="server"></ion-icon>
                </div>

                <h3 class="h3 card-title">e-RISITI WEB</h3>

                <p class="card-text">
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem.
                </p>

              </div>
            </li>

          </ul>

        </div>
      </section>





      <!-- 
        - FEATURES
      -->

      <section class="features" id="features">
        <div class="container">

          <h2 class="h2 section-title">ABOUT US</h2>

          <p class="section-text">

            e-Risiti is an engine that shall be able  to provide electronic receipts for any custome need 
                   
           
          </p>

          <div class="features-wrapper">

            <figure class="features-banner">
              <!-- <img src="./assets/images/features-img-1.png" alt="illustration art"> -->
            </figure>

            <div class="features-content">

              <p class="features-content-subtitle">
                <ion-icon name="sparkles"></ion-icon>

                <span>CREATIVE FEATURES</span>
              </p>

              <h3 class="features-content-title">
                Build <strong>community</strong> & <strong>conversion</strong> with our suite of <strong>social
                  tool</strong>
              </h3>

              <p class="features-content-text">
                Temporibus autem quibusdam et aut officiis debitis aut rerum a necessitatibus saepe eveniet ut et
                voluptates repudiandae
                sint molestiae non recusandae itaque.
              </p>

              <ul class="features-list">

                <li class="features-list-item">
                  <ion-icon name="layers-outline"></ion-icon>

                  <p>Donec pede justo fringilla vel nec.</p>
                </li>

                <li class="features-list-item">
                  <ion-icon name="megaphone-outline"></ion-icon>

                  <p>Cras ultricies mi eu turpis hendrerit fringilla.</p>
                </li>

              </ul>

              <div class="btn-group">
                <button class="btn btn-primary">Read More</button>

                <button class="btn btn-secondary">Buy Now</button>
              </div>

            </div>

          </div>

          <div class="features-wrapper">

            <figure class="features-banner">
              <!-- <img src="./assets/images/features-img-2.png" alt="illustration art"> -->
            </figure>

            <div class="features-content">

              <p class="features-content-subtitle">
                <ion-icon name="sparkles"></ion-icon>

                <span>CREATIVE FEATURES</span>
              </p>

              <h3 class="features-content-title">
                We do the work you <strong>stay focused</strong> on <strong>your customers.</strong>
              </h3>

              <p class="features-content-text">
                Temporibus autem quibusdam et aut officiis debitis aut rerum a necessitatibus saepe eveniet ut et
                voluptates repudiandae
                sint molestiae non recusandae itaque.
              </p>

              <ul class="features-list">

                <li class="features-list-item">
                  <ion-icon name="rocket-outline"></ion-icon>

                  <p>Donec pede justo fringilla vel nec.</p>
                </li>

                <li class="features-list-item">
                  <ion-icon name="wifi-outline"></ion-icon>

                  <p>Cras ultricies mi eu turpis hendrerit fringilla.</p>
                </li>

              </ul>

              <div class="btn-group">
                <button class="btn btn-primary">Read More</button>

                <button class="btn btn-secondary">Buy Now</button>
              </div>

            </div>

          </div>

        </div>
      </section>







    </article>
  </main>





  <!-- 
    - FOOTER
  -->

  <footer>

    <div class="footer-top">
      <div class="container">

        <div class="footer-brand">

          <a href="#" class="logo">
            <!-- <img src="./assets/images/logo-footer.svg" alt="Landio logo"> -->
          </a>

          <p class="footer-text">
              An engine that provide electronic  receipt for any custome need
          </p>

          <ul class="social-list">

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-facebook"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-twitter"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-instagram"></ion-icon>
              </a>
            </li>

            <li>
              <a href="#" class="social-link">
                <ion-icon name="logo-linkedin"></ion-icon>
              </a>
            </li>

          </ul>

        </div>

        <div class="footer-link-box">

          <ul class="footer-list">

            <li>
              <p class="footer-item-title">ABOUT US</p>
            </li>

            <li>
              <a href="#" class="footer-link">Works</a>
            </li>

            <li>
              <a href="#" class="footer-link">Strategy</a>
            </li>

            <li>
              <a href="#" class="footer-link">Releases</a>
            </li>

           

          </ul>

          <ul class="footer-list">

            <li>
              <p class="footer-item-title">CUSTOMERS</p>
            </li>

            <li>
              <a href="#" class="footer-link">Tranding</a>
            </li>

            <li>
              <a href="#" class="footer-link">Popular</a>
            </li>

         
          </ul>

          <ul class="footer-list">

            <li>
              <p class="footer-item-title">SUPPORT</p>
            </li>

            <li>
              <a href="#" class="footer-link">Developers</a>
            </li>

            <li>
              <a href="#" class="footer-link">Support</a>
            </li>

            <li>
              <a href="#" class="footer-link">Customer Service</a>
            </li>

          </ul>

        </div>

      </div>
    </div>

    <div class="footer-bottom">
      <div class="container">
        <p class="copyright">
          &copy; 2022 <a href="">e-RISITI</a>. All Right Reserved
        </p>
      </div>
    </div>

  </footer>

<!-- login model -->

<div class="clas row">
<div class=" offset-3 cont modal modal-xl " id="myModal">
<div class="container2 " id="container">
	<div class="form-container sign-up-container" id="institute">
		<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
		<form action="#">
			<h1>Create Account</h1>
			<span>or use your email for registration</span>
			<input type="text"  placeholder="Name" />
			<input type="email" placeholder="Email" />
			<input type="password" placeholder="Password" />
			<button>Sign Up</button><br/>
        <span class="accStatus" @click="removePanel">I have an account</span><br/><br/>
		</form>
	</div>
	<div class="form-container sign-up-container" id="Govt">
		<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
		<form action="#">
			<h1>Create Account</h1>
			<!-- <span>or use your email for registration</span> -->
			<input type="text"  placeholder="Name" />
			<input type="email" placeholder="Email" />
			<input type="password" placeholder="Password" />
			<button>Sign Up</button><br/>
        <span class="accStatus" @click="removePanel">I have an account</span><br/><br/>
		</form>
	</div>
	<div class="form-container sign-in-container">
		<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
		<form action="#" @submit="validateForm" name="myForm">
			<h1>Sign in</h1>
			<!-- <span>or use your account</span> -->
			<input type="email" id="email" placeholder="Email"  required/>
			<input type="password" id="passwd" placeholder="Password" required />
			<a href="#">Forgot your password?</a>
			<button  @click="validateForm">Sign In</button><br/>
             <span class="accStatus" @click="addPanel">I don't have an account</span><br/>
		</form>
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>Welcome Back!</h1>
				<p>To keep connected with us please login with your personal details</p>
				<button class="ghost" id="signIn" @click="removePanel">Sign In</button>
			</div>
			<div class="overlay-panel overlay-right">
				<h1>Hi There!</h1>
				<p>Enter your personal details to open an account with us</p>
				<button class="ghost" id="signUp" @click="addPanel">Sign Up</button>
			</div>
		</div>
	</div>
</div>
 
</div>
</div>

<!-- end login modal -->

 </div>
</template>

<script>
export default {
  name: "ProfileView",

    data(){
             return{
             closepass:document.getElementById('regForm'),
             };
            },
          methods : {
            addPanel: function(){
                const container = document.getElementById('container');
                container.classList.add("right-panel-active");
            },

             removePanel: function(){
                const container = document.getElementById('container');
                container.classList.remove("right-panel-active");
            }, 
               },
 
};
</script>
<style scoped>

/* .clas{
} */

* {
	box-sizing: border-box;
}
h1 {
	font-weight: bold;
	margin: 0;
}

h2 {
	text-align: center;
}

.accStatus{
    display: none;
}

p {
	font-size: 14px;
	font-weight: 100;
	line-height: 20px;
	letter-spacing: 0.5px;
	margin: 20px 0 30px;
    font-family: 'Montserrat', sans-serif;
}

span {
	font-size: 12px;
    margin-bottom: 12px;
}

a {
	color: #333;
	font-size: 14px;
	text-decoration: none;
	margin: 15px 0;
}

button {
	border-radius: 20px;
	border: 1px solid #F2eee3;
	background-color: #e3eff2;
	color: black;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
	border-color: #42A5F5;
}

button:active {
	transform: scale(0.95);
}

button:focus {
	outline: none;
}

button.ghost {
	color: white;
	background-color: transparent;
	border-color: rgb(255, 255, 255);
}

form {
	background-color: #FFFFFF;
	display: flex;
	align-items: center;
	justify-content: center;
	flex-direction: column;
	padding: 0 50px;
	height: 100%;
	text-align: center;
}

input {
	background-color: #e9fff8;
	/* border: none; */
	padding: 12px 15px;
	margin: 8px 0;
	width: 100%;
	outline: 0;
  border-width: 12px 7px 2px;
  border-color: #42A5F5;
border-radius: 20px;
}

.container2 {
	background-color: #fff;
	border-radius: 10px;
    box-shadow: 0 14px 28px rgba(0,0,0,0.25),
    0 10px 10px rgba(0,0,0,0.22);
	position: relative;
	overflow: hidden;
	width: 768px;
	max-width: 100%;
	min-height: 500px ;
    margin-top: 3%;
    display: flex;
    padding: 0 30% 0;
    /* flex-direction: column; */
}

.form-container {
	position: absolute;
	top: 0;
	height: 100%;
	transition: all 0.6s ease-in-out;
}

.sign-in-container {
	left: 0;
	width: 50%;
	z-index: 2;
}

.container2.right-panel-active .sign-in-container {
	transform: translateX(100%);
}

.sign-up-container {
	left: 0;
	width: 50%;
	opacity: 0;
	z-index: 1;
}

.container2.right-panel-active .sign-up-container {
	transform: translateX(100%);
	opacity: 1;
	z-index: 5;
	animation: show 0.6s;
}

.overlay-container {
	position: absolute;
	top: 0;
	left: 50%;
	width: 50%;
	height: 100%;
	overflow: hidden;
	transition: transform 0.6s ease-in-out;
	z-index: 100;
}

.container2.right-panel-active .overlay-container{
	transform: translateX(-100%);
}

.overlay {
	background: #cbf1e5;
	/* background: -webkit-linear-gradient(to bottom right, #a73103, #260d50); */
	background: linear-gradient(to bottom right, #42A5F5, #009688);
	background-repeat: no-repeat;
	background-size: cover;
	background-position: 0 0;
	color: black;
	position: relative;
	left: -100%;
	height: 100%;
	width: 200%;
transform: translateX(0);
	transition: transform 0.6s ease-in-out;
}

.container2.right-panel-active .overlay {
transform: translateX(50%);
}

.overlay-panel {
	position: absolute;
	display: flex;
	align-items: center;
	justify-content: center;
	flex-direction: column;
	padding: 0 40px;
	text-align: center;
	top: 0;
	height: 100%;
	width: 50%;
	transform: translateX(0);
	transition: transform 0.6s ease-in-out;
}

.overlay-left {
	color: white;
	transform: translateX(-20%);
}

.container2.right-panel-active .overlay-left {
	transform: translateX(0);
}

.overlay-right {
	color: white;
	right: 0;
	transform: translateX(0);
}

.container2.right-panel-active .overlay-right {
	transform: translateX(50%);
}

.social-container {
	margin: 20px 0;
}
.cont{
  margin-top: 5%;
}
.close{
  border: none;
  background: none;
}
.close:hover{color: red;
}



@media only screen and (max-width: 600px) {
 .sign-up-container {
	left: 0;
	width: 100%;
	opacity: 0;
	z-index: 1;
    /* display: none; */
    }

    .sign-in-container {
	left: 0;
	width: 100%;
	z-index: 2;
    }
    .accStatus{
    display: block;
}
.container2.right-panel-active .sign-in-container {
	transform: translateX(90%);
}
.container2.right-panel-active .sign-up-container {
	transform: translateX(0%);
	opacity: 1;
	z-index: 5;
	animation: show 0.9s;
}
.overlay-container {
	position: absolute;
	top: 0;
	left: 0%;
	width: 0%;
	height: 0%;
}


.cont{
	padding: 4%;
}
.overlay-right {
	right: 0%;
	transform: translateX(-100%);
}
}

</style>
